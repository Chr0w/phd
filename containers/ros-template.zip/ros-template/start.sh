#!/bin/bash

./build.sh
./run.sh
